package Entidades;

public interface List<T> {

}
